<!Doctype html>
<html lang="{{ str_replace('_','-',app()->getlocale())}}" >
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">

<title>{{config('app.name','Laravel Test')}}</title>
</head>

<body>
<div id="app">
    <nav class="navbar navbar -expand">
    <div class="container">
    <a class="navbar-brand" href="{{url('/') }}">
    </a>
    <button class="navbar-tooggler" type="button">
    </button>

    </div>
</div>
</body>