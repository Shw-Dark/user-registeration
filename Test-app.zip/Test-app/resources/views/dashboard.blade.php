@extends('layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
      <div class="container-fluid">
          <div class="row mb-2">
              <div class="col-sm-6">
                  <h1 class="m-0">{{ $page_title }}</h1>
              </div>
              <!-- /.col -->
              <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                      <li class="breadcrumb-item active">{{ $page_title }}</li>
                  </ol>
              </div>
              <!-- /.col -->
          </div>
          <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
 <!-- Main content -->
 <section class="content">
    <div class="container-fluid">

        <!-- Dashboard main box -->
        <div class="row">
            <div class="col-xl-3 col-md-6 col-sm-6 overview-box">
                <a href="{{ route('manufacturers.index') }}" class="card position-relative border-0 text-decoration-none box-shadow" data-trigger="hover" data-toggle="tooltip" title="Count of Manufactures">
                    <!-- <div class="ribbon-wrapper">
                        <div class="ribbon bg-secondary">
                          <small>Brands</small>
                        </div>
                    </div> -->
                    <div class="card-body">
                        <div class="row m-0">
                            <div class="col-12 px-1">
                                <h6 class="text-uppercase">Total Manufacturers</h6>
                                <h2 class="font-weight-bold manufacturers numbers-font"></h2>
                                <!-- <p class="mb-0"><small class="Manufacturerproducts"> </small></p> -->
                            </div>
                            <div class="tile-icon px-1 text-right">
                                <i class="fas fa-industry"></i>
                            </div>                            
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-6 overview-box">
                <a href="{{ route('categories.index') }}" class="card position-relative border-0 text-decoration-none box-shadow" data-trigger="hover" data-toggle="tooltip" title="Count of Categories">
                    <!-- <div class="ribbon-wrapper">
                        <div class="ribbon bg-secondary">
                          <small>Category</small>
                        </div>
                    </div> -->
                    <div class="card-body">
                        <div class="row m-0">
                            <div class="col-12 px-1">
                                <h6 class="text-uppercase">Total Categories</h6>
                                <h2 class="font-weight-bold categories numbers-font"></h2>
                                <!-- <p class="mb-0"><small class="categoryProducts"> </small></p> -->
                            </div>
                            <div class="tile-icon px-1 text-right">
                                <i class="fas fa-clipboard-list"></i>
                            </div>                            
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-6 overview-box">
                <a href="{{ route('products.index') }}" class="card position-relative border-0 text-decoration-none box-shadow" data-trigger="hover" data-toggle="tooltip" title="Count of Products">
                    <!-- <div class="ribbon-wrapper">
                        <div class="ribbon bg-secondary">
                            <small>SKU's</small>
                        </div>
                    </div> -->
                    <div class="card-body">
                        <div class="row m-0">
                            <div class="col-12 px-1">
                                <h6 class="text-uppercase">Total Products</h6>
                                <h2 class="font-weight-bold products numbers-font"></h2>
                            </div>
                            <div class="tile-icon px-1 text-right">
                                <i class="fas fa-shopping-basket"></i>
                            </div>                            
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-md-6 col-sm-6 overview-box">
                <a href="{{ route('attributes.index') }}" class="card position-relative border-0 text-decoration-none box-shadow" data-trigger="hover" data-toggle="tooltip" title="Count of Attributes">
                    <!-- <div class="ribbon-wrapper">
                        <div class="ribbon bg-secondary">
                            <small>Keywords</small>
                        </div>
                    </div> -->
                    <div class="card-body">
                        <div class="row m-0">
                            <div class="col-12 px-1">
                                <h6 class="text-uppercase">Total Attributes</h6>
                                <h2 class="font-weight-bold attributes numbers-font"></h2>
                            </div>
                            <div class="tile-icon px-1 text-right">
                                <i class="fas fa-tag"></i>
                            </div>                            
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Single bar card start-->
        <!-- Completeness items -->
        <div class="row">
            <div class="col-12">
                <div class="complete-box">
                    <div class="py-2">
                        <h5 class="cart-title d-inline-block text-bold">Quality (Overall)</h5>
                    </div>
                    <div class="">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                                <!-- <a href="#" class="small-box text-dark" data-toggle="tooltip" title="Count of Products with complete filled information" data-trigger="hover"> -->
                                <span class="small-box text-dark" data-toggle="tooltip" title="Count of Products with complete filled information" data-trigger="hover">
                                <div class="inner">
                                    <p class="mb-2">Completed Products</p>
                                    <h5 class="numbers-font"><strong><span class="required-product"></span> of <span class="total-product"></span></strong> <small><em>(<span class="complete-item"></span>%)</em></small></h5>
                                    <div id="completeItems"></div>
                                </div>
                                <!-- </a> -->
                                </span>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                                <!-- <a href="#" class="small-box text-dark" data-toggle="tooltip" title="Count of Products with Images" data-trigger="hover"> -->
                                <span class="small-box text-dark" data-toggle="tooltip" title="Count of Products with Images" data-trigger="hover">
                                    <div class="inner">
                                        <p class="mb-2">Product with Images</p>
                                        <h5 class="numbers-font"><strong><span id="productWithImages">  </span> of <span id="total-products">  </span></strong> <small><em>(<span id="itemPercentage">  </span>)</em></small></h5>
                                        <div id="itemWidth"></div>
                                    </div>
                                <!-- </a> -->
                                </span>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                                <!-- <a href="#" class="small-box text-dark" data-toggle="tooltip" title="Count of Attributes that has complete values" data-trigger="hover"> -->
                                <span class="small-box text-dark" data-toggle="tooltip" title="Count of Attributes that has complete values" data-trigger="hover">
                                    <div class="inner">
                                        <p class="mb-2">Completed Product Attributes</p>
                                        <h5 class="numbers-font"><strong><span id="complete-attribute"> </span> of <span id="total-attribute"> </span></strong> <small><em>(<span id="total-attribute_percentage"> </span>)</em></small></h5>
                                        <div id="completedFields"></div>
                                    </div>
                                <!-- </a> -->
                                </span>
                            </div>
                            <!-- <div class="col-lg-3 col-6">
                                <a href="#" class="small-box text-dark">
                                    <div class="inner">
                                        <p class="mb-2">Quality Aging</p>
                                        <h5><strong>49 of 98</strong> <small><em>(50%)</em></small></h5>
                                        <div id="translatedFields"></div>
                                    </div>
                                    </a>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Single bar card end-->

        <!-- Attributes -->
        <!-- <div class="row">
            <div class="col-12">
                <div class="card no-shadow card-primary">
                    <div class="card-header rounded">
                        <div class="form-inline mb-0">
                            <label for="" class="mb-1 mr-2 font-weight-normal">Category</label>
                            <select name="" id="selectcategory" class="form-control form-control-sm min-w200">
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="row">
            <div class="col-lg-6 col-sm-12">
                <div class="card card-primary card-outline box-shadow">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-list mr-1"></i> Quality By Category <small class="text-sm"><em>(Bottom Ten)</em></small></h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <!-- <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                            </button> -->
                        </div>
                    </div>
                    <div class="card-body" data-toggle="tooltip" title="List of Categories that requires immediate actions">
                        <div id="reuiredAttr"></div>
                        <hr class="border-top border-secondary mt-0 mb-0">
                        <div id="cat-quality-score" class="pt-1 bg-whitegray"></div>
                        <hr class="border-top border-secondary mt-0 mb-0">
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-sm-12">
                <div class="card card-primary card-outline box-shadow">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-industry mr-1"></i> Quality By Manufacturer - Category <small class="text-sm"><em>(Bottom Ten)</em></small></h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <!-- <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                            </button> -->
                        </div>
                    </div>
                    <div class="card-body" data-toggle="tooltip" title="List of Manufacturers that requires immediate actions">
                        <div id="alldAttr"></div>
                        <hr class="border-top border-secondary mt-0 mb-0">
                        <div id="manu-quality-score" class="pt-1 bg-whitegray"></div>
                        <hr class="border-top border-secondary mt-0 mb-0">
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card card-primary card-outline box-shadow">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-images mr-1"></i> Image Counts</h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                            <!-- <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                            </button> -->
                        </div>
                    </div>
                    <div class="card-body" data-toggle="tooltip" title="Count of Product Images">
                        <div id="image-count-graph"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card card-primary card-outline box-shadow">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-list-alt mr-1"></i> Syndicated Content</h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body" data-toggle="tooltip" title="Count of Products with Syndicated Content">
                        <div id="syndicated-content"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Completeness by channels -->
        <!-- <div class="row">
            <div class="col-12">
                <div class="complete-box">
                    <h5 class="cart-title d-inline-block text-bold mb-3 text-navy">Completeness (By Channel)</h5>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="card card-outline card-navy">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-shopping-bag mr-1"></i> eCommerce</h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="ecommerce"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card card-outline card-navy">
                    <div class="card-header py-2">
                        <h5 class="card-title d-inline-block mb-0"><i class="fas fa-network-wired mr-1"></i> ERP</h5>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="mobile"></div>
                    </div>
                </div>
            </div>
        </div> -->


        <!-- <div class="row">
            <div class="col-lg-8">
                <div class="card card-outline card-navy">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                        <i class="fas fa-clipboard-list mr-1"></i>
                        To Do List
                        </h5>

                        <div class="card-tools">
                        <ul class="pagination pagination-sm">
                            <li class="page-item"><a href="#" class="page-link">«</a></li>
                            <li class="page-item"><a href="#" class="page-link">1</a></li>
                            <li class="page-item"><a href="#" class="page-link">2</a></li>
                            <li class="page-item"><a href="#" class="page-link">3</a></li>
                            <li class="page-item"><a href="#" class="page-link">»</a></li>
                        </ul>
                        </div>
                    </div>
                    <div class="card-body">
                        <ul class="todo-list ui-sortable" data-widget="todo-list">
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo1" id="todoCheck1">
                                    <span class="checkmark"></span>
                                </label>
                            <label for="todoCheck1"></label>
                            </div>
                            <span class="text">Add CTQ (Critical to Quality) parameter for Air Conditioner Category</span>
                        </li>
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo2" id="todoCheck2">
                                    <span class="checkmark"></span>
                                </label>
                            <label for="todoCheck2"></label>
                            </div>
                            <span class="text">Add images to Refrigerators Category</span>
                        </li>
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo3" id="todoCheck3">
                                    <span class="checkmark"></span>
                                </label>
                            <label for="todoCheck3"></label>
                            </div>
                            <span class="text">Add new Attribute Group named "Channel Specific"</span>
                        </li>
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo4" id="todoCheck4">
                                    <span class="checkmark"></span>
                                </label>
                            <label for="todoCheck4"></label>
                            </div>
                            <span class="text">Export list of latest manufacturers added in the system</span>
                        </li>
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo5" id="todoCheck5">
                                    <span class="checkmark"></span>
                                </label>
                                <label for="todoCheck5"></label>
                            </div>
                            <span class="text">Create a report for product that requires Energy Guide</span>
                        </li>
                        <li>
                            <span class="handle ui-sortable-handle">
                            <i class="fas fa-ellipsis-v"></i>
                            <i class="fas fa-ellipsis-v"></i>
                            </span>
                            <div class="icheck-primary d-inline-block ml-2">
                                <label class="cust-checkbox d-inline-block pl-3">
                                    <input type="checkbox" value="" name="todo6" id="todoCheck6">
                                    <span class="checkmark"></span>
                                </label>
                            <label for="todoCheck6"></label>
                            </div>
                            <span class="text">Request Admin to add a new user for Graphic team</span>
                        </li>
                        </ul>
                    </div>
                    <div class="card-footer py-2 clearfix">
                        <button type="button" class="btn btn-secondary btn-sm float-right"><i class="fas fa-plus"></i> Add item</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card card-outline card-navy">
                    <div class="card-header py-2">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-globe mr-1"></i>
                            Most Frequently Used Views
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row border border-left-0 border-right-0 mb-2 mx-0">
                            <div class="col-2 px-0">
                                <div class="card bg-primary d-inline-block rounded-0 w-100 mb-0">
                                    <div class="card-body text-center px-2 py-3">
                                        <i class="fas fa-shopping-basket fa-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 px-0">
                                <div class="px-1 py-3">
                                    <p class="mb-0"><small>Products</small></p>
                                </div>
                            </div>
                            <div class="col-4 px-0 text-right">
                                <div class="px-1">
                                    <a href="#" class="btn btn-skyblue btn-sm rounded-0 mt-3">More Info</a>
                                </div>
                            </div>
                        </div>
                        <div class="row border border-left-0 border-right-0 mb-2 mx-0">
                            <div class="col-2 px-0">
                                <div class="card bg-primary d-inline-block rounded-0 w-100 mb-0">
                                    <div class="card-body text-center px-2 py-3">
                                        <i class="fas fa-list fa-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 px-0">
                                <div class="px-1 py-3">
                                    <p class="mb-0"><small>Categories</small></p>
                                </div>
                            </div>
                            <div class="col-4 px-0 text-right">
                                <div class="px-1">
                                    <a href="#" class="btn btn-skyblue btn-sm rounded-0 mt-3">More Info</a>
                                </div>
                            </div>
                        </div>
                        <div class="row border border-left-0 border-right-0 mb-2 mx-0">
                            <div class="col-2 px-0">
                                <div class="card bg-primary d-inline-block rounded-0 w-100 mb-0">
                                    <div class="card-body text-center px-2 py-3">
                                        <i class="fas fa-tags fa-sm"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 px-0">
                                <div class="px-1 py-3">
                                    <p class="mb-0"><small>Attribute Product Report</small></p>
                                </div>
                            </div>
                            <div class="col-4 px-0 text-right">
                                <div class="px-1">
                                    <a href="#" class="btn btn-skyblue btn-sm rounded-0 mt-3">More Info</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card card-outline card-secondary">
                    <div class="card-header py-2">
                        <h5 class="card-title mb-0"><i class="fas fa-clipboard-check mr-1"></i> Reports</h5>
                    </div>
                    <div class="card-body">
                        <ol>
                            <li>Items on web</li>
                            <li>Items missing shipping next</li>
                            <li>Dimensions missing</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div> -->

    </div>
</section>
<!-- /.content --> 
@endsection


@section('script')

<!-- Highcharts Script Starts -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<!-- <script src="{{ asset('dist/js/assets/highcharts/highcharts.min.js') }}"></script>    -->
<!-- <script src="{{ asset('dist/js/assets/highcharts/rounded-corners.min.js') }}"></script> -->

<!-- Item with images -->
<script>
    /**
     *
     * Function to get Count Item With Images On 21-01-2020 by Shekhar
     * Modified On 28-02-2020 by Shekhar
     *
     */
    function itemWithImages(){
        let imageCount_url = "{{ route('api.product_images.productImageCount', ['org_id' => getOrganizationData('id')]) }}";
        let totalProducts = 0
        let ProductWithImage = 0;
        $.get(imageCount_url, function(response){
            $.each(response.data, function(key, value){
                totalProducts = totalProducts + value.productCountSum;
                if(value.imageCount!=0){
                    ProductWithImage = ProductWithImage + value.productCountSum;
                }
            });
            let image_percentage =  mathFun((ProductWithImage / totalProducts) * 100);
            let non_image_percentage = 100 - image_percentage;
            let totalProductLength = totalProducts.toString().length;
            let totalProductsCount = totalProductLength <= 3 ? totalProducts : mathFun(Number((totalProducts / 1000)).toLocaleString()) +' k';
            let totalPrductsCount = ProductWithImage.toString().length <=3 ? ProductWithImage : mathFun(Number((ProductWithImage / 1000)).toLocaleString()) +' k';
            
            $('#total-products').text(totalProductsCount);
            $('#productWithImages').text(totalPrductsCount);
            $('#itemPercentage').text(image_percentage +' %');
            singleBarChart('itemWidth', Number(image_percentage) , non_image_percentage ,'Items With Images');
        });
    }
	/**
	* Script to get count for completeness product 10-01-2019 by Deepmala 
	* Modified On 21-01-2020 by Shekhar
    *
	*/
	function getCompleteItem(){
        var completeproduct_url = "{{ route('api.compute_scores.requiredproductcount', ['completeValue'=> 100, 'org_id' => getOrganizationData('id')]) }}";

        let products_count_url = "{{ route('api.products.recordCount', ['org_id' => getOrganizationData('id')]) }}";
        let totalProducts = getCountCardsrecords(products_count_url, 'products');
		$.get(completeproduct_url, function(response){
            /**
            * For Complete Products
            */
            let data = response.data[0];
            let completeProduct = data['requiredCompleteProduct'];
            let completeItem = data['requiredCompleteProduct'].toString().length <=3 ? Number(data['requiredCompleteProduct']) : mathFun(Number((Number(data['requiredCompleteProduct']) / 1000)).toLocaleString()) +' k';

            let totalCompleteItem = totalProducts.toString().length <=3 ? Number(totalProducts) : mathFun(Number((Number(totalProducts) / 1000)).toLocaleString()) +' k';

            //The badget counts
            $(".required-product").html(completeItem);
			$(".total-product").html(totalCompleteItem);
            let perCentage = mathFun((completeProduct / totalProducts) * 100);
            $(".complete-item").html(perCentage);
            let non_percentage = 100 - perCentage;
            singleBarChart('completeItems', parseFloat(perCentage), parseFloat(non_percentage), 'Completed Items');
            /**
            * For Completed Attribute
            * Modified On 21-01-2020 by Shekhar
            */
            let attribute_percentage = Number(data['compeledFieldsPer']).toFixed(2);
            attribute_percentage = (attribute_percentage=='' || attribute_percentage== null) ? 0 : attribute_percentage;
            let attribute_nonePercentage = 100 - attribute_percentage;

            let completeAttribute = data['totalComplete'].length <=3 ? Number(data['totalComplete']) : mathFun(Number((Number(data['totalComplete']) / 1000))).toLocaleString() +' k';
            
            let totalAttribute = data['totalAttribute'].length <= 3 ? Number(data['totalAttribute']) : mathFun(Number((Number(data['totalAttribute']) / 1000))).toLocaleString() +' k';
           
            completeAttribute = (completeAttribute=='' || completeAttribute== null) ? 0 : completeAttribute;
            totalAttribute = (totalAttribute=='' || totalAttribute== null) ? 0 : totalAttribute;
            //The badget counts
            $('#complete-attribute').text(completeAttribute);
            $('#total-attribute').text(totalAttribute);
            $('#total-attribute_percentage').text(attribute_percentage +' %');
            singleBarChart('completedFields', Number(attribute_percentage), Number(attribute_nonePercentage.toFixed(2)), 'Completed Fields');

            // Added comma in numbers starts from here
            function numberWithCommas(number) {
                var parts = number.toString().split(".");
                parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                return parts.join(".");
            }
            $(document).ready(function() {
                $("#complete-attribute, #total-attribute, .required-product, .total-product, #productWithImages, #total-products").each(function() {
                    var num = $(this).text();
                    var commaNum = numberWithCommas(num);
                    $(this).text(commaNum);
                });
            });
            // Added comma in numbers ends here

		});
	}
    /**
     *
     * Function to initialise the Single Bar Highchart On 21-01-2020 by Shekhar
     * Modified On 21-01-2020 by Shekhar
     *
     * Here chart Name :Highchart id to show
     * show_percentage : percentage to show Highlighted on Bar
     * hide_percentage : percentage to Not Highlighted on Bar
     *
     */
    function singleBarChart(chart_name, show_percentage, hide_percentage, tooltip_name){
        
        Highcharts.chart(chart_name, {
            renderTo : chart_name,
            chart: {
                type: 'bar',
                height: 17.5,
                margin: [0, 0, 0, 0],
                padding: [0, 0, 0, 0],
                backgroundColor: 'rgba(255, 255, 255, 0)',
                borderWidth: 0,
            },
            title: {
                text: '',
            },
            xAxis: {
                categories: [''],
                labels: {
                    enabled: false,
                },
                gridLineWidth: 0,
                lineColor: 'transparent',
                minorGridLineWidth: 0,
            },
                yAxis: {
                    min: 0,
                    max: 100,
                    enabled: false,
                    title: {
                        text: ''
                    },
                    labels: {
                        enabled: false
                    },
                    gridLineWidth: 0,
                    minorGridLineWidth: 0,
                },
                legend: {
                    reversed: true,
                    enabled: false,
                },
                plotOptions: {
                    series: {
                        stacking: 'normal',
                        pointWidth: 10.5,
                        //borderRadius: 10,
                        borderWidth: 0,
                    }
                },
                tooltip: {
                    outside: true,
                },
                series: [{
                data: [hide_percentage],   // not visible data non_record_percentage %
                borderRadiusTopLeft: '20px',
                borderRadiusTopRight: '20px',
                color: '#cacaca',
                enableMouseTracking: false,
                }, {
                name: tooltip_name,
                data: [show_percentage],      // calculated record_percentage % 
                zones: [{
                    value: 49,
                    color: '#c5202a'
                    }, {
                        value: 70,
                        color: '#e5be14'
                    }, {
                        value: 100,
                        color: '#2c6a77'
                }],
                borderRadiusBottomLeft: '20px',
                borderRadiusBottomRight: '20px',
                //color: '#efce6b',
                }]
            });
        }
</script>
<script>
/**
*
* function to load Highcharts of type Bar by Shekhar
* Modified On 
*
* */
$(function(){
    let categoryscore_url = "{{ route('api.compute_scores.categoryscore', ['org_id' => getOrganizationData('id')]) }}";

    let manufacturerScore_url = "{{ route('api.compute_scores.manufacturescore', ['org_id' => getOrganizationData('id')]) }}";

    getQualityRecords(categoryscore_url, 'Category');

    getQualityRecords(manufacturerScore_url, 'Manufacturer');
    
    Highcharts.setOptions({
		lang: {
			thousandsSep: ','
		}
	});
});
/**
*
*function to get records for Highchart of type Bar by Shekhar
*
* */
function getQualityRecords(api_url ,chart_name){
    let qualityZones = [{value: 51, color: '#c5202a'}, {value: 71, color: '#e5be14'},{ value: 101, color: '#2c6a77'}];
    let fontstyle = {
                        wordBreak: 'break-all',
                        textOverflow: 'allow',
                        fontSize: '13px',
                        fontWeight: '600',
                    };
    let bgColor = '#efefef';
    
    $.ajax({
        url: api_url,
        method: "GET",
        dataType: "JSON",
        success:function(response){
            let data =response.data;
           // console.log(data);
            let top_ten_data = data.slice(0,10);
            let total_bar_data = calculatePercentage(data, chart_name);
            let barData = calculatePercentage(top_ten_data, chart_name);
            let qualityScore = [];

            let scoreData = [Number(total_bar_data[3].average_count)];
            scoreData = isNaN(scoreData)? 0 : scoreData;
            //console.log(scoreData);
            let totalScoredata = [Number(total_bar_data[4].total_average)];
            totalScoredata = isNaN(totalScoredata)? 0 : totalScoredata;
            //console.log(totalScoredata);


            if(chart_name== 'Category'){
                let url = "<a target='_blank' href='{{ route('compute_scores.category') }}'>Quality Score</a>  ";

                qualityScore = [url + Math.round(scoreData)+'%'];

                barTypeChart('cat-quality-score', chart_name , qualityScore, totalScoredata ,scoreData , qualityZones ,40, fontstyle, bgColor);

                barTypeChart('reuiredAttr', chart_name , barData[0].name, barData[1].data1 , barData[2].data2, qualityZones);

            }else if(chart_name== 'Manufacturer'){
                let url = "<a target='_blank' href='{{ route('compute_scores.manufacture') }}'> Quality Score</a>  ";

                qualityScore = [url+Math.round(scoreData)+'%'];

                barTypeChart('manu-quality-score',chart_name , qualityScore, totalScoredata ,scoreData , qualityZones ,40, fontstyle, bgColor);

                barTypeChart('alldAttr',chart_name, barData[0].name, barData[1].data1 , barData[2].data2, qualityZones);
            }         
        }
    });
}
/**
*
*function calculate average and percentages records for Highchart of type Bar
*
* Modified on 14-01-2020
*
* */
function calculatePercentage(data, chart_name)
{
    let show_url_name = '';
    let api_url = '';
    var name = [];
    let barperc1 = [];
    let barperc2 = [];
    let returnArray = [];
    let count = data.length;
    let sum = 0;
    let averageCount = 0;
    let category_name='';
    $.each(data, function(key, value){
        let productAttributCount = value.sumReqAttribute*value.productCount;
        let productReqAttributCount = value.sumReqTotalAttribute*value.productCount;
        let percentageAtt = (productReqAttributCount/productAttributCount)*100;
        let returnPer = 0; 
        if(!isNaN(percentageAtt)){
            if(Number.isInteger(percentageAtt)){
                returnPer = percentageAtt;
            }else{
                returnPer = percentageAtt.toFixed(2);
            }
        }
        if(chart_name== 'Category'){
         api_url = route('products.index', {
                    'category_id': value.category_id
                    }).url();
        }else if(chart_name== 'Manufacturer'){
            api_url = route('manufacturers.show', {
                    'manufacturer': value.manufacturer_id,
                    'category_id': value.category_id
                    }).url();
            category_name = '- '+value.category_name;
        }
        show_url_name = "<a target='_blank' title='Show Details' href='" + api_url + "'>" + value.name.charAt(0).toUpperCase() + value.name.slice(1) +' '+ category_name + "</a>";
        sum = sum + Number(returnPer);
        data1per = 100 - returnPer;
        data1perc = isNaN(data1per)? 0 :data1per.toFixed(2);
        name.push(show_url_name);
        barperc1.push(Number(data1perc));
        barperc2.push(Number(returnPer));
    });
    averageCount = sum / count;
    let totalAverage = 100 - averageCount;
    returnArray.push({'name':name}, {'data1':barperc1}, {'data2':barperc2}, {'average_count':averageCount.toFixed(2)}, {"total_average":totalAverage.toFixed(2)});
    return returnArray;
}
/**
*
* function defination for Highcharts of type bar
* here chartName = chart name where to load chart
* categories = load categories names array
* no_record_data = load array of percentages which is in gray color 
* record_data = load array of percentages which is in colored
* height = height for bars
* 
* Modified on 14-01-2020
* add labels in  xAxis
*
* */
function barTypeChart(chartName, tooltip_chartname,  categories='', no_record_data='', record_data='', zones='',height='', fontstyle='', bgColor ){

    Highcharts.chart(chartName, {
        renderTo : chartName,
        chart: {
            type: 'bar',
            height: height,
            backgroundColor: bgColor,
        },
        title: {
            text: '',
        },
        plotOptions: {
            series: {
                stacking: 'normal'
            }
        },
        xAxis: {
            categories: categories , // categories var here
            gridLineWidth: 0,
            lineColor: 'transparent',
            minorGridLineWidth: 0,
            labels: {   
                useHTML:true,
                allowOverlap:true,
                    style: fontstyle
                    // {
                    //     wordBreak: 'break-all',
                    //     textOverflow: 'allow',
                    //     fontSize: '13px',
                    //     fontWeight: '600',
                    // }
                },
            },
        yAxis: {
            min: 0,
            max: 100,
            enabled: false,
            title: {
                text: ''
            },
            labels: {
                enabled: false
            },
            gridLineWidth: 0,
            minorGridLineWidth: 0,
        },
        tooltip: {
            outside: true,
            valueSuffix: '%',
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span> <b>{point.y}</b> of total<br/>'
        },
        legend: {
            //reversed: true,
            enabled: false,
        },
        plotOptions: {
            series: {
                name: tooltip_chartname,
                stacking: 'normal',
                pointWidth: 10.5,
                //borderRadius: 10,
                borderWidth: 0,
            }
        },
        series: [{
            data: no_record_data ,   // data1 var here
            borderRadiusTopLeft: '20px',
            borderRadiusTopRight: '20px',
            color: '#cacaca',
            enableMouseTracking: false,
            },
            {
            data: record_data ,    // data present and calculations  data2 var here
            zones: zones ,   // zones var here
            colorByPoint: true,
            borderRadiusBottomLeft: '20px',
            borderRadiusBottomRight: '20px',
            dataLabels: {
                enabled: false,
                crop: false,
                formatter: function () {
                    return Math.round(100 * this.y / this.total) + '%';
                },
            }
        }]

    });
}
</script>

<!-- Image Counts -->
<script type="text/javascript">
    getImageCountData();
    function getImageCountData()
    {
        let color = ['#c5202a','#e5be14','#417bbf','#2c6a77'];
        let org_id = "{{ getOrganizationData('id') }}";
        var imageCount_url = "{{ route('api.product_images.productImageCount', ['org_id' => getOrganizationData('id')]) }}";
        let imageCount_graph_data = [];
        let imageCount_graph_link = {};

        $.ajax({
            url:imageCount_url,
            method:'GET',
            dataType:'JSON',
            success:function(response){
                let data = response.data;
                let newImagecount = sortByKeyAsc(data, "imageCountKey");
                let count = 0;
                $.each(data, function(key, val){
                    value_name = (val.imageCountKey == 0)? 'No Images' : val.imageCountKey; 
                    // value_count = parseInt(val.productCountSum); 
                    value_count = (val.productCountSum == 25) ? 35 : val.productCountSum; 
                    imageCount_graph_data.push( {'name':value_name , 'y':value_count, 'color':color[count], 'hrefLink': "/products-images"} );
                    count++;
                });
                imageCountGraph(imageCount_graph_data);
            }
        });

    }
	function sortByKeyAsc(array, key) {
        return array.sort(function (a, b) {
            var x = a[key]; var y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }
    function imageCountGraph(imageCountArrayNew){

            Highcharts.chart('image-count-graph', {
            chart: {
                "renderto": "image-count-graph",
                type: 'column'
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'category',
                labels: {
                    formatter: function () {
                        let urlParmetrer = (this.value == 'No Images'?'0':(this.value =='0-3'?'1-3':this.value)); 
                    //console.log(urlPar);
                        return '<a href="products-images?img-count='+urlParmetrer+'">' +
                            this.value + '</a>';
                    },
                    style: {
                        fontSize: '12px',
                    }
                },
                title: {
                    text: 'Images Count',
                    style: {
                        fontWeight: '700',
                        color: '#000',
                    }
                }
            },
            yAxis: {
                // minRange: 0,
                title: {
                    text: 'Product Count',
                    style: {
                        fontWeight: '700',
                        color: '#000',
                    }
                }

            },
            legend: {
                enabled: false
            },
            plotOptions: {
                series: {
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true,
                        allowOverlap: true
                        //format: '{point.y:.1f}%'
                    }
                }
            },

            tooltip: {
                headerFormat: '<span style="font-size:11px"><a href="{point.hrefLink}">{series.name}</a></span><br>',
                pointFormat: '<span style="color:{point.color}; cursor:pointer;">{point.name}</span>: <b>{point.y}</b> of total<br/>'
            },
            
            series: [
                {
                pointFormatter: function() {
                    var string = '';
                    Highcharts.each(toolTip[this.series.data.indexOf(this)], function(p) {
                        string += '<a href="http://www.google.com">catgeory</a><br>'
                    });
                    return string + "<br />";
                    },                              
                    name: "Images Count",
                    colorByPoint: true,
                    data: imageCountArrayNew
                }
            ],
        });
    }
	
	// var imageCountArray = [];var imageCountArrayNew = [];
	// function getReturnData( imageCountValue, productCount, colorCode, linkPass){
	// 	imageCountArrayNew.push({
	// 				name: imageCountValue, 
	// 				y:  productCount,
	// 				color:colorCode,
	// 				hrefLink:linkPass
	// 			});
	// 	return imageCountArrayNew;	
    // }
    
    /*var x_AxisValue = {'No Images':'/products-images','1-3':'/products-images/1-3','4-6':'/products-images/4-6','7+':'/products-images/7+'};*/
    
    // var x_AxisValue = {'No Images':'/products-images','1-3':'/products-images','4-6':'/products-images','7+':'/products-images'};
	// $.each(x_AxisValue, function(key, value) {
	// 	// var tt = getReturnData(key,0, 0,value);
	// 	 //console.log('returnResult : '+tt);
	// });
	
	// var colorArray = ['#c5202a','#e5be14','#417bbf','#2c6a77'];
	
	// var imageCount_url = "{{ route('api.product_images.productImageCount', ['org_id' => getOrganizationData('id')]) }}";

	// $.get(imageCount_url,function( response){
        
	// 	var data = response.data; //console.log(data);
    //     var dataLength = data.length;
	// 	imageCountArray = sortByKeyAsc(data, "imageCountKey");
		
	// 	let countOne_Three = 0;
	// 	let countFour_Six = 0;
	// 	let countSeven_Ten = 0;
	// 	let countTen_plus = 0;
	// 	let returnResult = 0;
		
	// 	let no_image = 'No Images';
	// 	let first_bar = '1-3';
	// 	let second_bar = '4-6';
	// 	let third_bar = '7+';
		
	// 	for(var i=0; i<dataLength; i++){
	// 		let imageCountValue = data[i]['imageCountKey'];
	// 		let productCount = data[i]['productCountSum'];
	// 		let colorCode = colorArray[i];
	// 		if(imageCountValue == 0){
	// 		    imageCountValue = no_image;
	// 		}
	// 		//console.log('imageCountValue '+imageCountValue); console.log('productCount '+productCount); console.log('colorCode '+colorCode);
    //         returnResult = getReturnData(imageCountValue,productCount,colorCode,'/products-images');
    //         console.log('---------------------------------------------');
    //         console.log(returnResult);
	// 	}
		
	// 	//console.log('imageCountArrayNew : '+imageCountArrayNew);
		
	// 	/*
	// 	for(var i=0; i<dataLength; i++){
	// 		let imageCountValue = data[i]['imageCount'];
	// 		let productCount = data[i]['productCount'];
	// 		let colorCode = data[i]['color'];
			
	// 		if(imageCountValue == 0){
			    
	// 			imageCountValue = no_image;
	// 			let countSend = productCount;
	// 			returnResult = getReturnData(imageCountValue,countSend,'#c5202a','/products-images');
	// 			//console.log('returnResult : '+returnResult);
	// 		}else if(imageCountValue > 0 && imageCountValue < 4){
	// 			imageCountValue = first_bar;
	// 			countOne_Three += productCount;
	// 			returnResult = getReturnData(imageCountValue,countOne_Three,'#e5be14','/products-images/1-3');
	// 		}else if(imageCountValue > 3 && imageCountValue < 7){
	// 			if ($.inArray(second_bar, imageCountArrayNew) != -1){ console.log('deep');
	// 				//var index = imageCountArrayNew.findIndex(p => p.name == second_bar)
	// 				//console.log('index : '+index);//myArray.splice(i,1);
	// 			}
	// 			//var index = imageCountArrayNew.findIndex(p => p.name == second_bar)
	// 			//console.log('index : '+index);
	// 			imageCountValue = second_bar;
	// 			countFour_Six += productCount;
	// 			returnResult = getReturnData(imageCountValue,countFour_Six,'#417bbf','/products-images/4-6');
	// 		}else if(imageCountValue > 6){
	// 			imageCountValue = third_bar;
	// 			countSeven_Ten += productCount;
	// 			returnResult = getReturnData(imageCountValue,countSeven_Ten,'#2c6a77','/products-images/7-10');
	// 		}
			
	// 	}
	// 	*/

	// 	var imageLinks = x_AxisValue;
       
	// 	Highcharts.chart('image-count', {
    //     chart: {
    //         type: 'column'
    //     },
    //     title: {
    //         text: ''
    //     },
    //     xAxis: {
    //         type: 'category',
    //         labels: {
    //             formatter: function () {
    //                 let urlParmetrer = (this.value == 'No Images'?'0':(this.value =='0-3'?'1-3':this.value)); 
    //                //console.log(urlPar);
    //                 return '<a href="products-images?img-count='+urlParmetrer+'">' +
    //                     this.value + '</a>';
    //             },
    //             style: {
    //                 fontSize: '12px',
    //             }
    //         },
    //         title: {
    //             text: 'Images Count',
    //             style: {
    //                 fontWeight: '700',
    //                 color: '#000',
    //             }
    //         }
    //     },
    //     yAxis: {
    //         //max: 1000,
    //         title: {
    //             text: 'Product Count',
    //             style: {
    //                 fontWeight: '700',
    //                 color: '#000',
    //             }
    //         }

    //     },
    //     legend: {
    //         enabled: false
    //     },
    //     plotOptions: {
    //         series: {
    //             borderWidth: 0,
    //             dataLabels: {
    //                 enabled: true,
    //                 //format: '{point.y:.1f}%'
    //             }
    //         }
    //     },

    //     tooltip: {
    //         headerFormat: '<span style="font-size:11px"><a href="{point.hrefLink}">{series.name}</a></span><br>',
    //         pointFormat: '<span style="color:{point.color}; cursor:pointer;">{point.name}</span>: <b>{point.y}</b> of total<br/>'
    //     },
		
        // series: [
        //     {
        //        pointFormatter: function() {
		// 		  var string = '';
		// 		  Highcharts.each(toolTip[this.series.data.indexOf(this)], function(p) {
		// 			string += '<a href="http://www.google.com">catgeory</a><br>'
		// 		  });                  
		// 		  return string + "<br />";
		// 		},
			                 
	// 		    name: "Images Count",
    //             colorByPoint: true,
    //             data: imageCountArrayNew
	// 		}
    //     ],
    // });
		
// });
//	console.log(imageCountArray);
	
</script>

<!-- Syndicate Content -->

<script>
/**
*
* syndicatedContrnt() to show syndicated content graph 
* On Date 29-01-2020
* By Shekhar
*
* contentLinks :- to redirect url
*
*/
function syndicatedContent(graph_data, contentLinks){
    
    Highcharts.chart('syndicated-content', {
        "renderto": "syndicated-content",
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        xAxis: {
            type: 'category',
            labels: {
                formatter: function () {
                    // return '<a href="' + contentLinks[this.value] + '">' +
                    //     this.value + '</a>';
                    return this.value;
                },
                style: {
                    fontSize: '12px',
                }
            },
            title: {
                text: 'Syndicated Content',
                style: {
                    fontWeight: '700',
                    color: '#000',
                }
            }
        },
        yAxis: {
            //max: 1000,
            title: {
                text: 'Product Count',
                style: {
                    fontWeight: '700',
                    color: '#000',
                }
            },
        },
        legend: {
            enabled: false
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    //format: '{point.y:.1f}%'
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b> of total<br/>'
        },
        setOptions:{
                lang: {
                    thousandsSep: ','
                }
            },
        series: [
            {
                name: "Syndicated Content",
                colorByPoint: true,
                data: graph_data
            }
        ],
    });
}
/**
*
* getSyndicatedAttributeCount() to get syndicated attribute count 
* On Date 29-01-2020
* By Shekhar
*
* contentLinks :- to redirect url
*
*/
function getSyndicatedAttributeCount()
{
    let color = ['#c5202a','#e5be14','#417bbf','#2c6a77'];
    let field_type = 'third_party';
    let org_id = "{{ getOrganizationData('id') }}";
    let api_url = route('api.syndicated_content.index', {'org_id':org_id , 'field_type':field_type }).url();
    let syndicated_graph_data = [];
    let syndicated_graph_link = {};

    $.ajax({
        url:api_url,
        method:'GET',
        dataType:'JSON',
        success:function(response){
            let name = '';
            let url = '#';
            let data = response.data;
            let count = 0;
            data.sort(function (a,b){ return  a.sort_order - b.sort_order });
            $.each(data, function(key, val){
                let syndicatedCount = val.syndicate_count.toLocaleString();
                url = '#'
				value_name = val.name; 
                syndicated_graph_data.push( {'name':value_name , 'y':val.syndicate_count, 'color':color[count]} );
				if(value_name != 'No content'){
                   url = route('attributes.product_report', {'search_id':0, 'attribute_id':val.attribute_id}).url();
				}
                syndicated_graph_link[value_name] = url;
                count++;
            });
            syndicatedContent(syndicated_graph_data, syndicated_graph_link); //graph display function
        }
    });
}
</script>
<!-- eCommerce
<script>
    Highcharts.chart('ecommerce', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Completeness',
            align: 'left',
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: false
                },
                showInLegend: true
            }
        },
        legend: {
            symbolHeight:12,
            borderWidth: 0,
            symbolRadius: 0
        },
        series: [{
            name: 'Completed',
            data: [
                { name: 'Attributes', y: 61.41 },
                { name: 'Images', y: 11.84 },
                { name: 'Categories', y: 10.85 },
                { name: 'Manufacturers', y: 4.67 }
            ]
        }]
    });
</script> -->

<!-- mobile
<script>
    Highcharts.chart('mobile', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Completeness',
            align: 'left',
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: false
                },
                showInLegend: true
            }
        },
        legend: {
            symbolHeight:12,
            borderWidth: 0,
            symbolRadius: 0
        },
        series: [{
            name: 'Completed',
            data: [
                { name: 'Attributes', y: 61.41 },
                { name: 'Images', y: 11.84 },
                { name: 'Categories', y: 10.85 },
                { name: 'Manufacturers', y: 4.67 }
            ]
        }]
    });
</script> -->

<!-- Highcharts Script Ends -->

<script>
/**
* Script to get all tiles count  Modified On 21-01-2020 shekhar
*
*/
$(document).ready(function() {
    getSyndicatedAttributeCount();  // function to call syndicated data 29-01-2020
    getCompleteItem();          // function call for complete item 
    itemWithImages();           // function call for item with Image count

    let manufature_count_url = "{{ route('api.manufacturers.record-count', ['org_id' => getOrganizationData('id')]) }}";
    let categories_count_url = "{{ route('api.categories.record-count', ['org_id' => getOrganizationData('id')]) }}";
    let products_count_url = "{{ route('api.products.recordCount', ['org_id' => getOrganizationData('id')]) }}";
    let attribute_count_url = "{{ route('api.attributes.recordCount', ['org_id' => getOrganizationData('id')]) }}";
    getCountCardsrecords(manufature_count_url, 'manufacturers');
    getCountCardsrecords(categories_count_url, 'categories');
    getCountCardsrecords(products_count_url, 'products');
    getCountCardsrecords(attribute_count_url,'attributes');
});

let returnResponce = '';

function getCountCardsrecords(api_url, card_name){
       $.ajax({
            url:api_url,
            method:"GET",
            dataType:"JSON",
            async :false,
            success:function(response){
                if(card_name=='manufacturers'){
                    $('.manufacturers').text(response.data[0].manufactureCount.toLocaleString());
                    returnResponce = response.data[0].manufactureCount;
                }else if(card_name=='categories'){
                    $('.categories').text(response.data[0].categoryCount.toLocaleString());
                    returnResponce = response.data[0].categoryCount;
                }else if(card_name=='products'){
                    $('.products').text(response.data.toLocaleString());
                    returnResponce = response.data;
                }else if(card_name=='attributes'){
                    $('.attributes').text(response.data.toLocaleString());
                    returnResponce = response.data;
                }
            }
        });
        return returnResponce;
    }
/**
* function to return value with single place after decimal point.
*/
function mathFun(par){
    let value = par.toString().split('.');
        return value[0]+(value[1] === undefined? '' : '.'+value[1][0]);
}
</script>
@endsection
