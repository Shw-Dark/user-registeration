<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Hash;

class RegisterController extends Controller
{
    //Register function
    public function register(){
       // return view('auth.register');

    }

    //store user 
    public function store(Request $request)
    {
        $request->validate([
        'name'=>'required|string|max:255',
        'email'=>'required|string|email|max:255|unique:users',
        'mobile'=>'required|min:10|',
        'password'=>'required|string|min:8|confirmed',
        'password_confirmation'=>'required'

        ]);

       $user= User::Create([
            'name'=>$request->name,
            'email'=>$request->email,
            'mobile'=>$request->mobile,
            'password'=>Hash::make($request->password),
        ]);

        return redirect('welcome');
        
    }
}
